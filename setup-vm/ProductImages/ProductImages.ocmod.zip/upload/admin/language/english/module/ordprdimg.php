<?php
// Heading
$_['heading_title']    = 'Product Image In Order Confirmation Email';
$_['doc_title']    = 'Product Image In Order Confirmation Email';

$_['text_module']      = 'Modules';
$_['text_success']     = 'Success: You have modified Product Image In Order Confirmation Email module!';
$_['text_edit']        = 'Edit product Image In Order Confirmation Email Module';

// Entry
$_['entry_status']     = 'Status';
$_['entry_image_size']     = 'Image Size';
$_['entry_image_col_name']     = 'Image Column Name';

// Error
$_['error_permission'] = 'Warning: You do not have permission to modify Product Image In Order Confirmation Email module!';